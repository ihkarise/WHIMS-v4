# WHIMS — Wise Homeopathy Inventory Management System

A mobile-first inventory app for Wise Homeopathy's medicine stock (853 medicines).
Built as a static web app (GitHub Pages) talking to a Google Sheet via a Google Apps Script backend. No server to maintain, no database to pay for — the Google Sheet *is* the database.

## What it does

- **Dashboard** — six bottle-cap status tiles (total, out of stock, low, in stock, need-purchase, archived); tap a tile to jump to that filtered list.
- **Search** — find any medicine in seconds by name, ID, potency, category, or supplier, with quick filter chips.
- **Receive / Dispense / Adjust / Archive** — every action writes straight to the sheet and logs a transaction row.
- **Orders** — auto-grouped purchase list by supplier, sorted by reorder priority, with Copy-list and WhatsApp buttons.
- **History** — colour-coded audit trail of every stock movement.
- Works offline with a cached copy; syncs when the backend is reachable.

## Files in this repo

| File | Role |
|---|---|
| `index.html` | The app UI (HTML + CSS). Upload to GitHub Pages. |
| `app.js` | Frontend logic. Upload to GitHub Pages. |
| `Code.gs` | The Google Apps Script backend. Paste into Apps Script, **not** GitHub Pages. |
| `WHIMS_Inventory_FINAL.xlsx` | Starter spreadsheet (853 medicines, Inventory + Transactions tabs). Import into Google Sheets. |
| `SETUP_GUIDE.md` | Full step-by-step setup (~20 min, no coding). |
| `WH_UI_PLAN.md` | The Wise Homeopathy design system, reusable for future tools. |

## Quick start

Full instructions are in **`SETUP_GUIDE.md`**. In short:

1. **Sheet** — Import `WHIMS_Inventory_FINAL.xlsx` into a new Google Sheet (replace spreadsheet). Keep the two tab names exactly: `Inventory` and `Transactions`.
2. **Backend** — Sheet → Extensions → Apps Script → paste `Code.gs` → Deploy as Web app (Execute as *Me*, access *Anyone*). Copy the `/exec` URL.
3. **App** — Put `index.html` and `app.js` in a GitHub repo → Settings → Pages → branch `main` / root. Your app goes live at `https://YOUR-USERNAME.github.io/whims/`.
4. **Connect** — Open the app → Settings tab → paste the `/exec` URL → enter your name → Save → Refresh from sheet.

> Note: only `index.html` and `app.js` need to be served by GitHub Pages. `Code.gs` lives in Google Apps Script. The `.xlsx`, `SETUP_GUIDE.md`, and `WH_UI_PLAN.md` are reference files — harmless to keep in the repo.

## Tech notes

- No build step, no dependencies, no framework — plain HTML/CSS/JS.
- The backend uses a `LockService` lock so two staff editing at once can't overwrite each other.
- POST requests use `text/plain` to avoid the CORS preflight that Apps Script can't answer.
- Status (Out / Low / Good / Overstock) is computed both in the sheet (column S formula) and mirrored in the app.

## Security (v2)

The app is gated by a login screen. Passwords are verified inside Apps Script against salted SHA-256 hashes stored in **Script Properties** — Google's private vault. **No credentials, keys, or secrets exist anywhere in this repository**, so nothing needs to be removed before publishing it. Login issues a 6-hour session token; every API call requires it; 5 wrong passwords locks the account for 10 minutes.

To create users: open Apps Script → edit the `USERNAME`/`PASSWORD` lines inside `ADD_USER()` → run it once (▶) → blank the password line again. `LIST_USERS` and `REMOVE_USER` manage accounts.

Built for Wise Homeopathy Multispeciality Center.
