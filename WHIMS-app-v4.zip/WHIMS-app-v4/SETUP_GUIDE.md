# WHIMS — Setup Guide (No Coding Needed)

Wise Homeopathy Inventory Management System
Three parts: **Google Sheet → Apps Script backend → GitHub Pages app**. About 20 minutes total.

---

## PART 1 — The Google Sheet (5 min)

1. Go to **sheets.google.com** → blank spreadsheet.
2. **File → Import → Upload** → choose `WHIMS_Inventory_FINAL.xlsx` → Import location: **Replace spreadsheet**.
3. Check you now have two tabs at the bottom: **Inventory** and **Transactions**.
   The tab names must be exactly these two words — the backend looks for them by name.
4. Do not reorder or insert columns. Column S (Status) contains a formula — leave it alone.

---

## PART 2 — The Backend (Apps Script) (7 min)

1. In your Google Sheet: **Extensions → Apps Script**.
2. Delete the sample code in the editor.
3. Open `Code.gs` from this folder, copy **everything**, paste it into the editor.
4. Click the 💾 save icon. Name the project `WHIMS Backend`.
5. Click **Deploy → New deployment**.
6. Click the gear ⚙ next to "Select type" → choose **Web app**.
7. Set:
   - Description: `WHIMS v1`
   - Execute as: **Me**
   - Who has access: **Anyone**  ← important, otherwise the app cannot reach it
8. Click **Deploy** → **Authorize access** → choose your Google account → Advanced → Go to WHIMS Backend (unsafe) → Allow.
   (This warning is normal for your own private scripts.)
9. Copy the **Web app URL** — it ends in `/exec`. You'll paste this into the app in Part 4.

**Test it now:** open that URL in a browser with `?action=ping` added at the end.
You should see: `{"ok":true,"message":"WHIMS backend is live",...}`

---

## PART 3 — The App on GitHub Pages (5 min)

1. Go to **github.com** → log in → **New repository**.
2. Name: `whims` → Public → Create repository.
3. Click **uploading an existing file** → drag in `index.html` and `app.js` → Commit changes.
4. Go to **Settings → Pages** (left menu).
5. Under "Branch": choose **main** and **/ (root)** → Save.
6. Wait 1–2 minutes. Your app will be live at:
   `https://YOUR-USERNAME.github.io/whims/`

---

## PART 4 — Connect Them (2 min)

1. Open your app URL on your phone.
2. Go to the **Settings** tab (bottom right).
3. Paste the Apps Script URL from Part 2 → enter your name → **Save**.
4. Tap **Test connection** → you should see "✓ Backend is live".
5. Tap **Refresh from sheet** → the dashboard fills with your 853 medicines.

**Tip:** on your phone, open the app in Chrome → menu → **Add to Home screen**. It will behave like an installed app.

---

## Daily use

| Task | Where |
|---|---|
| Check stock levels | Dashboard tiles (tap a tile to see the list) |
| Find a medicine | Search tab — type name, ID, potency, or supplier |
| New stock arrived | Open medicine → **+ Receive** |
| Medicine given out | Open medicine → **− Dispense** (−1 / −2 / −5 / custom) |
| Physical count differs | Open medicine → **Adjust** |
| Stop stocking a medicine | Open medicine → **Archive** (never deleted; restore anytime) |
| Place orders | Orders tab → **Copy list** or **WhatsApp** |
| Audit trail | History tab, or the Transactions sheet itself |

Every action writes to the Google Sheet immediately and adds a row to Transactions. The sheet stays the single source of truth — you can always open it directly.

---

## If something goes wrong

- **"Cannot reach backend"** → In Apps Script, redeploy: Deploy → Manage deployments → ✏ edit → Version: New version → make sure access is **Anyone** → Deploy. The URL stays the same.
- **Changed the Code.gs file?** → You must create a **new version** in Manage deployments, or the live URL keeps running the old code.
- **"Sheet not found"** → Tab names must be exactly `Inventory` and `Transactions`.
- **Numbers wrong in the app** → Tap Refresh in Settings; the app shows a cached copy until it syncs.
- **Multiple staff** → Everyone uses the same app URL and same backend URL; the script uses a lock so two people can't overwrite each other.
