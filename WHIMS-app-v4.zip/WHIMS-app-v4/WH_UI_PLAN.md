# Wise Homeopathy — UI Plan & Design System
**For WHIMS and all future Wise Homeopathy digital tools** · v1.0

The system is built from your logo: the WH monogram in royal blue and crimson, with the falling-pellet motif. Blue carries structure and trust; red carries action and urgency; everything else stays quiet.

---

## 1. Color Tokens

| Token | Hex | Role |
|---|---|---|
| **WH Blue** | `#2A3C78` | Primary. Headers, navigation, primary buttons, headings, links |
| WH Blue Dark | `#1E2D5E` | Pressed states, gradients with WH Blue |
| WH Blue Tint | `#E9EDF7` | Selected chips, info badges, icon backgrounds |
| **WH Red** | `#C21F35` | Brand CTA, destructive actions (dispense, delete), urgent alerts, priority 5 |
| WH Red Tint | `#FAE7EA` | Error/alert backgrounds, out-of-stock badges |
| Background | `#F4F6FB` | App background (cool off-white — matches the blue family) |
| Surface | `#FFFFFF` | Cards, sheets, inputs |
| Ink | `#1C2440` | Body text |
| Muted | `#6A7390` | Secondary text, labels, captions |
| Line | `#E0E4EF` | Borders, dividers |

**Semantic status colors** (functional, never replaced by brand colors):

| Status | Color | Tint |
|---|---|---|
| Good / Success / Receive | `#1E8E5A` | `#E3F4EC` |
| Low stock / Warning | `#C77700` | `#FCF1DF` |
| Out of stock / Error / Dispense | WH Red `#C21F35` | `#FAE7EA` |
| Overstock / Info | WH Blue `#2A3C78` | `#E9EDF7` |

**The one rule that keeps it clean:** red means either *brand emphasis* or *something needs action* — never decoration. If a screen has more than two red elements, remove red from the least important one.

---

## 2. Typography

| Role | Font | Style |
|---|---|---|
| Headings, numbers, buttons | **Poppins** 700–800 | UPPERCASE, letter-spacing 0.04em |
| Body, forms, lists | **Inter** 400–600 | Sentence case |
| Data/captions | Inter 500 | 11–12px, muted color, uppercase labels at 0.05em |

Scale: 26px (stat numbers) · 16px (sheet/section titles) · 14–15px (body) · 11–12px (labels). Headings are blue by default; a single keyword may be red — never a full sentence in red (your existing brand rule, kept).

---

## 3. Shape & Depth

- Corner radius: **18px** cards · **12px** buttons/inputs · **99px** chips, search bar, badges
- Shadow: `0 4px 16px rgba(42,60,120,.09)` — one shadow level only
- Borders: 1.5px in Line color; focus rings 2px WH Blue
- Spacing rhythm: multiples of 4; cards padded 15–16px; 11px gaps in grids

---

## 4. Signature Elements

1. **Bottle-cap stat tiles** — every dashboard tile has a 9px colored strip on top (like a bottle cap): blue = neutral, red = critical, amber = warning, green = healthy. The strip *is* the data — color tells the story before the number.
2. **Pellet dot** — the falling-pellets motif from the logo appears as a small dot: under the active nav item, as the sync indicator, as list bullets in marketing material. Small, round, never more than 6px.
3. **Potency square** — medicines are identified by a rounded blue-tint square holding the potency (MT, 200, 1M). It works like an avatar for medicines.

---

## 5. Component Specs

**Buttons** (Poppins 700, uppercase, 14px padding, 12px radius)
- Primary / CTA → solid WH Red, white text (Save, Confirm, brand CTAs)
- Structural action → solid WH Blue, white text (Adjust, Copy, neutral actions)
- Receive / positive → solid Green `#1E8E5A`
- Dispense / destructive → solid WH Red
- Secondary → white, 1.5px Line border, WH Blue text

**Badges** — pill shape, 10.5px uppercase, tint background + strong text of same family (e.g. red tint bg + red text). Priority 5–4 get solid fills (red, orange); 3 and below get tints.

**Cards & lists** — white card, rows divided by 1px Line, row = [potency square] [name + meta] [number]. Numbers right-aligned in Poppins.

**Bottom navigation** — WH Blue bar, 5 items max, inactive = soft blue-grey `#8FA3B8`, active = white + red pellet dot.

**Bottom sheets** — all forms and details slide up from the bottom (one-hand mobile use), grab handle, background `#F4F6FB`, max-height 88vh.

**Forms** — labels above fields (uppercase, muted, 12.5px), inputs 11px padding, white. Required fields marked `*`. One primary button per sheet, always bottom-right.

---

## 6. Screen Map (WHIMS)

| Screen | Job | Key element |
|---|---|---|
| Dashboard | Status at a glance | 6 bottle-cap tiles → tap jumps to filtered search |
| Search | Find any medicine in <3 seconds | Sticky search bar + filter chips |
| Detail sheet | Everything about one medicine | Badges + key-value grid + 4 actions |
| Receive | Add stock | Green confirm; supplier prefilled |
| Dispense | Remove stock fast | −1 / −2 / −5 / custom quick grid |
| Orders | Purchase list by supplier | Priority-sorted groups, Copy + WhatsApp |
| History | Audit trail | +/− color-coded transaction feed |
| Settings | Connect & sync | API URL, user name, refresh |

---

## 7. Voice & Microcopy

- Buttons say what happens: "Receive stock", not "Submit"
- Errors say the fix: "Only 2 bottles in stock", not "Invalid quantity"
- Empty states invite action: "Nothing to order — no medicine has priority above 0"
- Numbers in Indian formats: ₹, en-IN dates

---

## 8. Reuse Checklist (for any new Wise Homeopathy tool)

1. Background `#F4F6FB`, white cards, 18px radius
2. WH Blue header bar with the Wh mark in red
3. Poppins uppercase headings, Inter body
4. Red only for CTA + urgent; status colors stay semantic
5. Bottom navigation + bottom sheets on mobile
6. One signature moment per screen (cap strip, pellet dot, or potency square) — never all three shouting at once

Paste sections 1–5 of this file into any AI Studio / Claude prompt as the design brief and the output will land on-brand.
